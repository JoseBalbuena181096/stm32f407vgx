#ifndef _Sensores_h
#define _Sensores_h
//#include"arduino.h"
class Sensores{
      private: 
             struct tresPots; 
      
   public:
   	
        
        void mostrarLeds(int _leds[3],int _pots[3]);
};
#endif

